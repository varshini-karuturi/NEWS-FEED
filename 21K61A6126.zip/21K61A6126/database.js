{\rtf1\ansi\ansicpg1252\cocoartf2636
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fswiss\fcharset0 Helvetica;}
{\colortbl;\red255\green255\blue255;}
{\*\expandedcolortbl;;}
\paperw11900\paperh16840\margl1440\margr1440\vieww28600\viewh18000\viewkind0
\pard\tx566\tx1133\tx1700\tx2267\tx2834\tx3401\tx3968\tx4535\tx5102\tx5669\tx6236\tx6803\pardirnatural\partightenfactor0

\f0\fs24 \cf0 const express = require('express');\
const MongoClient = require('mongodb').MongoClient;\
\
const app = express();\
const port = 3000;\
\
// MongoDB connection URI\
const mongoURI = 'your_mongodb_uri_here';\
const dbName = 'your_database_name_here';\
\
// Middleware to parse JSON in the request body\
app.use(express.json());\
\
app.get('/', (req, res) => \{\
    res.send('Hello, World!');\
\});\
\
const searchButton = document.getElementById("searchButton");\
const searchInput = document.getElementById("searchInput");\
const resultsContainer = document.getElementById("results");\
\
searchButton.addEventListener("click", async () => \{\
    const searchTerm = searchInput.value;\
\
    if (searchTerm.trim() !== "") \{\
        try \{\
            // Connect to MongoDB\
            const client = await MongoClient.connect(mongoURI, \{ useNewUrlParser: true, useUnifiedTopology: true \});\
            const db = client.db(dbName);\
\
            // Perform your search logic using the connected database\
            const searchResults = await db.collection('your_collection_name_here').find(\{ term: searchTerm \}).toArray();\
\
            // Display the search results\
            resultsContainer.innerHTML = <p>Search results for: $\{searchTerm\}</p>;\
            searchResults.forEach(result => \{\
                resultsContainer.innerHTML += <p>$\{result.title\}</p>; // Adjust this based on your database structure\
            \});\
\
            // Close the MongoDB connection\
            client.close();\
        \} catch (error) \{\
            console.error('Error:', error);\
            res.status(500).send('Internal Server Error');\
        \}\
    \}\
\});\
\
app.listen(port, () => \{\
    console.log(Server is running on port $\{port\});\
\});}